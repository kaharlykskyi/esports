<?php
return [
	'class' => 'yii\db\Connection',
	'dsn' => 'mysql:host=localhost;dbname=scort',
	'username' => 'kokos',
	'password' => 'web',
	'charset' => 'utf8',
];