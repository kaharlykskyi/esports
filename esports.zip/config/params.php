<?php

return [
    'adminEmail' => 'gemer.bumeen.group@gmail.com',
    'emailPass' => 'mike12111995',
    'EmailModerator' => 'moderator.bumeen.group@gmail.com',//pass 'mike12111995',
];
