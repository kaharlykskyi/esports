<?php

namespace app\models\systems;

use app\models\Tournaments;
use app\models\User;
use app\models\BallMatch;
use app\models\ScheduleTeams;
use Yii;

class LeagueSystem extends TournamentSystem
{
	protected function init ()
    {
        
    }

}