<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

$this->title = 'Admin Panel';

?>

<h1>Admin Panel</h1>

